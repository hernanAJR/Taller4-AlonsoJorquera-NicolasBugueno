package logica;
//Alonso Hernan Jorquera Rodriguez 20.948.058-1 ITI
//Nicolas Ignacio Bugueno Rementeria 20.007.300-2 ICCI
import dominio.Certificacion;
import dominio.Estudiante;

public class ValidacionPorAsignaturasCriticas implements EstrategiaValidacion {
    @Override
    public boolean validar(Estudiante e, Certificacion c) {
        return true;
    }
}


package logica;
//Alonso Hernan Jorquera Rodriguez 20.948.058-1 ITI
//Nicolas Ignacio Bugueno Rementeria 20.007.300-2 ICCI
import dominio.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.time.LocalDate;
import java.util.*;

public class Sistema implements ISistema {
    // SINGLETON
    private static Sistema instancia;

    //COLECCIONES
    private List<Usuario> usuarios;
    private List<Administrador> administradores;
    private List<Coordinador> coordinadores;
    private List<Estudiante> estudiantes;
    private List<Certificacion> certificaciones;
    private List<Curso> cursos;
    private List<Registros> registros;
    private List<Nota> notas;
    //SINGLETON
    private Sistema() {
        usuarios = new ArrayList<>();
        administradores = new ArrayList<>();
        coordinadores = new ArrayList<>();
        estudiantes = new ArrayList<>();
        certificaciones = new ArrayList<>();
        cursos = new ArrayList<>();
        registros = new ArrayList<>();
        notas = new ArrayList<>();
    }

    //SINGLETON
    /**
     * Consigue la instancia del Sistema.
     * 
     * @return la instancia del Sistema.
     */
    public static Sistema getInstancia() {
        if (instancia == null) {
            instancia = new Sistema();
        }
        return instancia;
    }
    //LECTURA ARCHIVOS
    /**
     * Carga los estudiantes a la lista desde el archivo.
     * 
     * @param ruta el nombre del archivo
     */
    public void cargarEstudiantes(String ruta) {
        try (Scanner archivo = new Scanner(new File(ruta))) {
            while (archivo.hasNextLine()) {
                String linea = archivo.nextLine();
                String[] partes = linea.split(";");

                String rut = partes[0];
                String nombre = partes[1];
                String carrera = partes[2];
                int semestre = Integer.parseInt(partes[3]);
                String correo = partes[4];
                String contrasena = partes[5];

                Usuario e = FactoryUsuarios.crearUsuario(
                    "Estudiante", rut, contrasena,
                    rut, nombre, carrera, semestre, correo, null
                );
                estudiantes.add((Estudiante) e);
                usuarios.add(e);
            }
        } catch (FileNotFoundException e) {
            System.out.println("Archivo no encontrado");
        }
    }
    /**
     * Carga los administradores a la lista desde el archivo.
     * 
     * @param ruta el nombre del archivo
     */
    public void cargarAdministradores(String ruta) {
        try (Scanner archivo = new Scanner(new File(ruta))) {
            while (archivo.hasNextLine()) {
                String linea = archivo.nextLine();
                String[] partes = linea.split(";");

                String nombreUsuario = partes[0];
                String contrasena = partes[1];

                Administrador admin = (Administrador) FactoryUsuarios.crearUsuario(
                    "Administrador", nombreUsuario, contrasena,
                    null, null, null, 0, null, null
                );
                administradores.add(admin);
                usuarios.add(admin);
            }
        } catch (FileNotFoundException e) {
            System.out.println("Archivo administradores.txt no encontrado");
        }
    }
    
    
    /**
     * Carga los coordinadores desde el archivo
     * 
     * @param ruta el nombre del archivo
     */
    public void cargarCoordinadores(String ruta) {
        try (Scanner archivo = new Scanner(new File(ruta))) {
            while (archivo.hasNextLine()) {
                String linea = archivo.nextLine();
                String[] partes = linea.split(";");

                String nombreUsuario = partes[0];
                String contrasena = partes[1];
                String area = partes[2];

                Coordinador coord = (Coordinador) FactoryUsuarios.crearUsuario(
                    "Coordinador", nombreUsuario, contrasena,
                    null, null, null, 0, null, area
                );
                coordinadores.add(coord);
                usuarios.add(coord);
            }
        } catch (FileNotFoundException e) {
            System.out.println("Archivo no encontrado");
        }
    }

    /**
     * Crea y carga los cursos desde el archivo
     * 
     * @param ruta el nombre del archivo
     */
    public void cargarCursos(String ruta) {
        try (Scanner archivo = new Scanner(new File(ruta))) {
            while (archivo.hasNextLine()) {
                String linea = archivo.nextLine();
                String[] partes = linea.split(";");

                String nrc = partes[0];
                String nombre = partes[1];
                int semestre = Integer.parseInt(partes[2]);
                int creditos = Integer.parseInt(partes[3]);
                String area = partes[4];

                //LISTA PRERRE
                List<String> prerrequisitos = new ArrayList<>();
                if (partes.length > 5 && !partes[5].isEmpty()) {
                    String[] listaPrerrequisitos = partes[5].split(",");
                    for (int i = 0; i < listaPrerrequisitos.length; i++) {
                        prerrequisitos.add(listaPrerrequisitos[i]);
                    }
                }

                cursos.add(new Curso(nrc, nombre, semestre, creditos, area, prerrequisitos));
            }
        } catch (FileNotFoundException e) {
            System.out.println("Archivo no encontrado");
        }
    }
    
    /**
     * Crea y carga las certificaciones desde el archivo
     * 
     * @param ruta el nombre del archivo
     */
    public void cargarCertificaciones(String ruta) {
        try (Scanner archivo = new Scanner(new File(ruta))) {
            while (archivo.hasNextLine()) {
                String linea = archivo.nextLine();
                String[] partes = linea.split(";");

                String id = partes[0];
                String nombre = partes[1];
                String descripcion = partes[2];
                int requisitos = Integer.parseInt(partes[3]);
                int validez = Integer.parseInt(partes[4]);

                certificaciones.add(new Certificacion(id, nombre, descripcion, requisitos, validez));
            }
        } catch (FileNotFoundException e) {
            System.out.println("Archivo certificaciones.txt no encontrado");
        }
    }
    /**
     * Crea y carga las notas desde el archivo
     * 
     * @param ruta el nombre del archivo
     */
    
    public void cargarNotas(String ruta) {
        try (Scanner archivo = new Scanner(new File(ruta))) {
            while (archivo.hasNextLine()) {
                String linea = archivo.nextLine();
                String[] partes = linea.split(";");

                String rut = partes[0];
                String codigoCurso = partes[1];
                double calificacion = Double.parseDouble(partes[2]);
                String estado = partes[3];
                String semestre = partes[4];
                Curso curso = null;
                for(Curso c : cursos) {
                	if (c.getNrc().equals(codigoCurso)){
                		curso=c;
                	}
                }
                
                Nota nota = new Nota(rut, codigoCurso, calificacion, estado, semestre);
                nota.setCurso(curso);
                for (int i = 0; i < estudiantes.size(); i++) {
                    Estudiante e = estudiantes.get(i);
                    if (e.getRut().equals(rut)) {
                        e.agregarNota(nota);
                        break;
                    }
                }
                notas.add(nota);
            }
        } catch (FileNotFoundException e) {
            System.out.println("Archivo notas.txt no encontrado");
        }
    }
    /**
     * Crea y carga los registros desde el archivo.
     * 
     * @param ruta el nombre del archivo
     */
    public void cargarRegistros(String ruta) {
        try (Scanner archivo = new Scanner(new File(ruta))) {
            while (archivo.hasNextLine()) {
                String linea = archivo.nextLine();
                String[] partes = linea.split(";");

                String rut = partes[0];
                String idCertificacion = partes[1];
                String fecha = partes[2];
                String estado = partes[3];
                double progreso = Double.parseDouble(partes[4]);

                registros.add(new Registros(rut, idCertificacion, fecha, estado, progreso));
            }
        } catch (FileNotFoundException e) {
            System.out.println("Archivo no encontrado");
        }
    }

    
    //Funcionalidades Menus
    
    //MENU ADMIN
    
    /**
     * Despliega el menu para administradores.
     */
    public void menuAdministrador() {
        Scanner teclado = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("----MENU ADMIN----");
            System.out.println("1. Crear Usuario");
            System.out.println("2. Modificar Estudiante");
            System.out.println("3. Modificar Coordinador");
            System.out.println("4. Eliminar Estudiante");
            System.out.println("5. Eliminar Coordinador");
            System.out.println("6. Eliminar Administrador");
            System.out.println("7. Restablecer Contraseña");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opción: ");

            opcion = teclado.nextInt();
            teclado.nextLine();

            switch(opcion) {
                case 1:
                    crearUsuario(teclado);
                    break;
                case 2:
                    modificarEstudiante(teclado);
                    break;
                case 3:
                    modificarCoordinador(teclado);
                    break;
                case 4:
                    eliminarEstudiante(teclado);
                    break;
                case 5:
                    eliminarCoordinador(teclado);
                    break;
                case 6:
                	restablecerContrasena(teclado);
                case 0:
                    System.out.println("Saliendo del menú administrador...");
                    break;
                default:
                    System.out.println("Opción inválida, intente nuevamente.");
            }
        } while(opcion != 0);
    }
    
    /**
     * Permite crear un usuario, implementa FactoryUsuarios.
     * 
     * @param teclado la entrada desde teclado
     */
    private void crearUsuario(Scanner teclado) {
        System.out.println("\n---- CREAR USUARIO ----");
        System.out.println("1. Estudiante");
        System.out.println("2. Coordinador");
        System.out.print("Seleccione el tipo de usuario: ");
        int tipo = teclado.nextInt();
        teclado.nextLine();

        if (tipo == 1) {
        	//LOS DATOS DEL ESTUDIANTE
            System.out.print("RUT: ");
            String rut = teclado.nextLine();

            System.out.print("Nombre completo: ");
            String nombre = teclado.nextLine();

            System.out.print("Carrera: ");
            String carrera = teclado.nextLine();

            System.out.print("Semestre: ");
            int semestre = teclado.nextInt();
            teclado.nextLine();

            System.out.print("Correo: ");
            String correo = teclado.nextLine();

            System.out.print("Contraseña: ");
            String contrasena = teclado.nextLine();

            Estudiante e = (Estudiante) FactoryUsuarios.crearUsuario(
                "Estudiante", rut, contrasena,
                rut, nombre, carrera, semestre, correo, null
            );

            estudiantes.add(e);
            usuarios.add(e);

            System.out.println("Estudiante creado exitosamente: " + e.getNombre());

        } else if (tipo == 2) {
            //DATOS DEL COORDINADOR
            System.out.print("Nombre de usuario (login): ");
            String nombreUsuario = teclado.nextLine();

            System.out.print("Contraseña: ");
            String contrasena = teclado.nextLine();

            System.out.print("Área de coordinación: ");
            String area = teclado.nextLine();

            // Crear y agregar
            Coordinador c = (Coordinador) FactoryUsuarios.crearUsuario(
                "Coordinador", nombreUsuario, contrasena,
                null, null, null, 0, null, area
            );

            coordinadores.add(c);
            usuarios.add(c);

            System.out.println("Coordinador creado exitosamente: " + c.getNombreUsuario());

        } else {
            System.out.println("Opción inválida.");
        }
    }

    
    /**
     * Permite eliminar un usuario (estudiante) segun un rut indicado
     * 
     * @param teclado la entrada desde teclado (rut)
     */
    private void eliminarEstudiante(Scanner teclado) {
        System.out.print("Ingrese RUT del estudiante a eliminar: ");
        String rut = teclado.nextLine();

        boolean encontrado = false;
        for (int i = 0; i < estudiantes.size(); i++) {
            if (estudiantes.get(i).getRut().equals(rut)) {
                estudiantes.remove(i);
                encontrado = true;
                break;
            }
        }

        if (encontrado) {
            System.out.println("Estudiante eliminado exitosamente.");
        } else {
            System.out.println("Estudiante no encontrado.");
        }
    }
    /**
     * Permite eliminar un coordinador segun su nombre de usuario.
     * 
     * @param teclado la entrada por teclado (nombre usuario coordinador)
     */
    private void eliminarCoordinador(Scanner teclado) {
        System.out.print("Ingrese nombre de usuario del coordinador a eliminar: ");
        String nombreUsuario = teclado.nextLine();

        boolean encontrado = false;
        for (int i = 0; i < coordinadores.size(); i++) {
            if (coordinadores.get(i).getNombreUsuario().equals(nombreUsuario)) {
                coordinadores.remove(i);
                encontrado = true;
                break;
            }
        }

        if (encontrado) {
            System.out.println("Coordinador eliminado exitosamente.");
        } else {
            System.out.println("Coordinador no encontrado.");
        }
    }
    /**
     * Permite modificar todos los atributos de un estudiante.
     * 
     * @param teclado las entradas por teclado (los nuevos valores de los atributos).
     */
    private void modificarEstudiante(Scanner teclado) {
        System.out.print("Ingrese RUT del estudiante a modificar: ");
        String rut = teclado.nextLine();

        boolean encontrado = false;
        for (int i = 0; i < estudiantes.size(); i++) {
            Estudiante e = estudiantes.get(i);
            if (e.getRut().equals(rut)) {
                System.out.print("Ingrese nuevo nombre: ");
                e.setNombre(teclado.nextLine());

                System.out.print("Ingrese nueva carrera: ");
                e.setCarrera(teclado.nextLine());

                System.out.print("Ingrese nuevo semestre: ");
                e.setSemestre(teclado.nextInt());
                teclado.nextLine();

                System.out.print("Ingrese nuevo correo: ");
                e.setCorreo(teclado.nextLine());

                System.out.print("Ingrese nueva contraseña: ");
                e.setContrasena(teclado.nextLine());

                encontrado = true;
                System.out.println("Estudiante modificado exitosamente.");
                break;
            }
        }

        if (!encontrado) {
            System.out.println("Estudiante no encontrado.");
        }
    }
    
    /**
     * Permite modificar los atributos de un coordinador segun su nombre de usuario.
     * 
     * @param teclado La nueva area de coordinacion.
     */
    private void modificarCoordinador(Scanner teclado) {
        System.out.print("Ingrese nombre de usuario del coordinador a modificar: ");
        String nombreUsuario = teclado.nextLine();

        boolean encontrado = false;
        for (int i = 0; i < coordinadores.size(); i++) {
            Coordinador c = coordinadores.get(i);
            if (c.getNombreUsuario().equals(nombreUsuario)) {
                System.out.print("Ingrese nueva área de coordinación: ");
                c.setAreaCoordinacion(teclado.nextLine());

                encontrado = true;
                System.out.println("Coordinador modificado exitosamente.");
                break;
            }
        }

        if (!encontrado) {
            System.out.println("Coordinador no encontrado.");
        }
    }
    
    /**
     * Permite restablecer las contraseñas de un coordinador o estudiante
     * 
     * @param teclado Nueva contreseña
     */
    private void restablecerContrasena(Scanner teclado) {
        System.out.println("\n---- RESTABLECER CONTRASEÑA ----");
        System.out.println("1. Estudiante");
        System.out.println("2. Coordinador");
        System.out.print("Seleccione el tipo de usuario: ");
        int tipo = teclado.nextInt();
        teclado.nextLine();

        switch (tipo) {
            case 1:
                System.out.print("Ingrese RUT del estudiante: ");
                String rutEst = teclado.nextLine();
                boolean encontradoEst = false;
                for (int i = 0; i < estudiantes.size(); i++) {
                    Estudiante e = estudiantes.get(i);
                    if (e.getRut().equals(rutEst)) {
                        System.out.print("Ingrese nueva contraseña: ");
                        e.setContrasena(teclado.nextLine());
                        encontradoEst = true;
                        System.out.println("Contraseña restablecida exitosamente para estudiante.");
                        break;
                    }
                }
                if (!encontradoEst) {
                    System.out.println("Estudiante no encontrado.");
                }
                break;

            case 2:
                System.out.print("Ingrese nombre de usuario del coordinador: ");
                String nombreCoord = teclado.nextLine();
                boolean encontradoCoord = false;
                for (int i = 0; i < coordinadores.size(); i++) {
                    Coordinador c = coordinadores.get(i);
                    if (c.getNombreUsuario().equals(nombreCoord)) {
                        System.out.print("Ingrese nueva contraseña: ");
                        c.setContrasena(teclado.nextLine());
                        encontradoCoord = true;
                        System.out.println("Contraseña restablecida exitosamente para coordinador.");
                        break;
                    }
                }
                if (!encontradoCoord) {
                    System.out.println("Coordinador no encontrado.");
                }
                break;

            default:
                System.out.println("Opción inválida.");
        }
    }
    
    
    //MENU COORDINADOR
    
    /**
     * Despliega el menu para coordinadores.
     * 
     */
    public void menuCoordinador() {
        Scanner teclado = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("\n=== Menú Coordinador ===");
            System.out.println("1. Gestionar Certificaciones");
            System.out.println("2. Panel de metricas");
            System.out.println("3. Validar Avances de Estudiantes");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opción: ");

            opcion = teclado.nextInt();
            teclado.nextLine(); // limpiar buffer

            switch(opcion) {
                case 1:
                    gestionarCertificaciones(teclado);
                    break;
                case 2:
                	panelMetricas(teclado);
                	break;
                case 3:
                    gestionEstudiantes(teclado);
                    break;
                case 0:
                    System.out.println("Saliendo del menú coordinador...");
                    break;
                default:
                    System.out.println("Opción inválida, intente nuevamente.");
            }
        } while(opcion != 0);
    }
    //1 Gestionar Certificaciones
    
    /**
     * Permite gestionar las certificaciones creadas (opción menú coordinador)
     * 
     * @param teclado La entrada por teclado
     */
    private void gestionarCertificaciones(Scanner teclado) {
        System.out.println("\n--- Gestión de Certificaciones ---");
        System.out.println("1. Crear Certificación");
        System.out.println("2. Modificar Certificación");
        System.out.println("3. Eliminar Certificación");
        System.out.print("Seleccione una opción: ");
        int opcion = teclado.nextInt();
        teclado.nextLine();

        switch(opcion) {
            case 1:
                crearCertificado(teclado);
                break;
            case 2:
                modificarCertificacion(teclado);
                break;
            default:
                System.out.println("Opción inválida.");
        }
    }
    /**
     * Permite modificar los atributos de una certificacion.
     * 
     * @param teclado Las entradas por teclado.
     */
    private void modificarCertificacion(Scanner teclado) {
        System.out.print("Ingrese ID de la certificación a modificar: ");
        String id = teclado.nextLine();

        boolean encontrada = false;
        for (int i = 0; i < certificaciones.size(); i++) {
            Certificacion c = certificaciones.get(i);
            if (c.getId().equals(id)) {
                System.out.println("Certificación encontrada: " + c.getNombre());

                System.out.print("Nuevo nombre: ");
                c.setNombre(teclado.nextLine());

                System.out.print("Nueva descripción: ");
                c.setDescripcion(teclado.nextLine());

                System.out.print("Minimo de creditos: ");
                c.setRequisitosCreditos(Integer.parseInt(teclado.nextLine()));

                System.out.print("Nueva validez (años): ");
                c.setValidezAnios(Integer.parseInt(teclado.nextLine()));

                encontrada = true;
                System.out.println("Certificación modificada exitosamente.");
                break;
            }
        }

        if (!encontrada) {
            System.out.println("Certificación no encontrada.");
        }
    }
    /**
     * Permite crear los certificados para todos los estudiantes que cumplen con los requisitos.
     * 
     * @param teclado El id de la certificacion.
     */
    private void crearCertificado(Scanner teclado) {
        System.out.print("Ingrese ID de la certificación: ");
        String id = teclado.nextLine();

        boolean generados = false;
        for (int i = 0; i < registros.size(); i++) {
            Registros r = registros.get(i);
            if (r.getIdCertificacion().equals(id) && r.getEstado().equalsIgnoreCase("Completada")) {
                //tipoCertificado??
                System.out.println("Generando certificado para estudiante RUT: " + r.getRutEstudiante());
                generados = true;
            }
        }

        if (!generados) {
            System.out.println("No hay estudiantes con certificación completada.");
        } else {
            System.out.println("Certificados generados exitosamente.");
        }
    }
    //3 Gestion Estudiantes
    
    /**
     * Despliega el menu para la gestion de estudiantes
     * 
     * @param teclado 
     */
    private void gestionEstudiantes(Scanner teclado) {
        int opcion;

        do {
            System.out.println("\n---- GESTION DE ESTUDIANTES ----");
            System.out.println("1. Consultar perfiles completos de estudiantes");
            System.out.println("2. Revisar y validar avances académicos");
            System.out.println("0. Volver al menú coordinador");
            System.out.print("Seleccione una opción: ");

            opcion = teclado.nextInt();
            teclado.nextLine(); // limpiar buffer

            switch(opcion) {
                case 1:
                    consultarPerfilEstudiante(teclado);
                    break;
                case 2:
                    validarAvances(teclado);
                    break;
                case 0:
                    System.out.println("Volviendo al menú coordinador...");
                    break;
                default:
                    System.out.println("Opción inválida, intente nuevamente.");
            }
        } while(opcion != 0);
    }
    
    
    /**
     * Permite consultar el perfil de un estudiante segun su RUT.
     * 
     * @param teclado El rut del estudiante
     */
    private void consultarPerfilEstudiante(Scanner teclado) {
        System.out.println("\n--- Consultar Perfil Estudiante ---");
        System.out.print("Ingrese RUT del estudiante: ");
        String rut = teclado.nextLine();

        boolean encontrado = false;
        for (int i = 0; i < estudiantes.size(); i++) {
            Estudiante e = estudiantes.get(i);
            if (e.getRut().equals(rut)) {
                encontrado = true;
                System.out.println("RUT: " + e.getRut());
                System.out.println("Nombre: " + e.getNombre());
                System.out.println("Carrera: " + e.getCarrera());
                System.out.println("Semestre: " + e.getSemestre());
                System.out.println("Correo: " + e.getCorreo());
                // Aquí luego podemos mostrar certificaciones inscritas, notas, etc.
                break;
            }
        }

        if (!encontrado) {
            System.out.println("Estudiante no encontrado.");
        }
    }    
    
    /**
     * Valida los avances de un estudiante según su rut (aplica Strategy)
     * 
     * @param teclado
     */
    private void validarAvances(Scanner teclado) {
        System.out.println("\n--- VALIDAR AVANCES ---");
        System.out.print("Ingrese RUT del estudiante: ");
        String rut = teclado.nextLine();

        Estudiante estudiante = (Estudiante) buscarUsuario(rut);
        if (estudiante == null) {
            System.out.println("Estudiante no encontrado.");
            return;
        }

        System.out.println("Seleccione estrategia de validación:");
        System.out.println("1. Por créditos");
        System.out.println("2. Por asignaturas críticas");
        System.out.println("3. Por promedio");
        int opcion = teclado.nextInt();
        teclado.nextLine();

        EstrategiaValidacion estrategia = null;
        switch(opcion) {
            case 1: 
            	estrategia = new ValidacionPorCreditos(); 
            break;
            case 2: 
            	estrategia = new ValidacionPorAsignaturasCriticas(); 
            	break;
            case 3: 
            	estrategia = new ValidacionPorPromedio(); 
            	break;
            default: 
            	System.out.println("Opción inválida."); 
            	return;
        }

        // APLICAR STRATEGY
        for (Registros r : registros) {
            if (r.getRutEstudiante().equals(rut)) {
                Certificacion c = buscarCertificacion(r.getIdCertificacion());
                if (c != null) {
                    boolean valido = estrategia.validar(estudiante, c);
                    System.out.println("Certificación: " + c.getNombre() +
                                       "- Validación: " + (valido ? "Cumple requisitos" : "No cumple"));
                }
            }
        }
    }

    
    
    //2
    /**
     * Despliega el menu de la opcion del panel de metricas
     * 
     * @param teclado La entrada por teclado.
     */
    private void panelMetricas(Scanner teclado) {
        System.out.println("\n--- METRICAS Y ANALISIS ---");
        System.out.println("1. Número de estudiantes inscritos en certificaciones");
        System.out.println("2. Asignaturas críticas más reprobadas");
        System.out.print("Seleccione una opción: ");
        int opcion = teclado.nextInt();
        teclado.nextLine();

        switch(opcion) {
            case 1:
                mostrarEstadisticasInscripciones();
                break;
            case 2:
            	analizarAsignaturasCriticas();
                break;
            default:
                System.out.println("Opción inválida.");
        }
    }
    
    /**
     * Muestra las estadisticas de inscripciones de las certificaciones
     * 
     */
    private void mostrarEstadisticasInscripciones() {
        System.out.println("\n--- ESTADISTICAS ---");

        for (int i = 0; i < certificaciones.size(); i++) {
            Certificacion c = certificaciones.get(i);
            int contador = 0;

            // Contar inscripciones en registros
            for (int j = 0; j < registros.size(); j++) {
                Registros r = registros.get(j);
                if (r.getIdCertificacion().equals(c.getId())) {
                    contador++;
                }
            }

            System.out.println("Certificación: " + c.getNombre() + " (ID: " + c.getId() + ") → " + contador + " inscripciones");
        }
    }
    /**
     * Permite ver el balance de reprobados en las asignaturas.
     * 
     */
    private void analizarAsignaturasCriticas() {
        System.out.println("\n--- ANALISIS ASIGNATURAS CRITICAS ---");

        boolean hayReprobadas = false;

        for (int i = 0; i < cursos.size(); i++) {
            Curso curso = cursos.get(i);
            int contadorReprobadas = 0;

            // Contar reprobaciones en notas
            for (int j = 0; j < notas.size(); j++) {
                Nota n = notas.get(j);
                if (n.getCodigoCurso().equals(curso.getNrc()) && n.getEstado().equalsIgnoreCase("Reprobada")) {
                    contadorReprobadas++;
                }
            }

            if (contadorReprobadas > 0) {
                hayReprobadas = true;
                System.out.println("Hay "+contadorReprobadas+" asignaturas reprobadas.");
                System.out.println("Asignatura: " + curso.getNombre() + " (Código: " + curso.getNrc() + "): " + contadorReprobadas + " reprobaciones");
            }
        }

        if (!hayReprobadas) {
            System.out.println("No se encontraron asignaturas críticas.");
        }
    }
    
    
    

    
    
    

    
    
    
    
    // Implementación de métodos de interfaz
    @Override
    public void agregarUsuario(Usuario usuario) {
        usuarios.add(usuario);
    }

    @Override
    public Usuario buscarUsuario(String nombreUsuario) {
        for (Usuario u : usuarios) {
            if (u.getNombreUsuario().equals(nombreUsuario)) {
                return u;
            }
        }
        return null;
    }

    @Override
    public void eliminarUsuario(String nombreUsuario) {
        boolean encontrado = false;

        for (int i = 0; i < usuarios.size(); i++) {
            Usuario u = usuarios.get(i);
            if (u.getNombreUsuario().equals(nombreUsuario)) {
                usuarios.remove(i);
                encontrado = true;
                break; 
            }
        }

        if (encontrado) {
            System.out.println("Usuario eliminado exitosamente.");
        } else {
            System.out.println("Usuario no encontrado.");
        }
    }

    @Override
    public void inscribirEstudianteEnCertificacion(String rutEstudiante, String idCertificacion) {
        Registros registro = new Registros(rutEstudiante, idCertificacion, 
                                            "", "Inscrito", 0.0);
        registros.add(registro);
    }

    @Override
    public List<Certificacion> obtenerCertificacionesEstudiante(String rutEstudiante) {
        List<Certificacion> resultado = new ArrayList<>();
        for (Registros r : registros) {
            if (r.getRutEstudiante().equals(rutEstudiante)) {
                for (Certificacion c : certificaciones) {
                    if (c.getId().equals(r.getIdCertificacion())) {
                        resultado.add(c);
                    }
                }
            }
        }
        return resultado;
    }

    @Override
    public void agregarCertificacion(Certificacion certificacion) {
        certificaciones.add(certificacion);
    }

    @Override
    public Certificacion buscarCertificacion(String idCertificacion) {
        for (Certificacion c : certificaciones) {
            if (c.getId().equals(idCertificacion)) {
                return c;
            }
        }
        return null;
    }

    @Override
    public void agregarCurso(Curso curso) {
        cursos.add(curso);
    }

    @Override
    public Curso buscarCurso(String nrc) {
        for (Curso c : cursos) {
            if (c.getNrc().equals(nrc)) {
                return c;
            }
        }
        return null;
    }

    @Override
    public void generarReporteCertificaciones() {
        System.out.println("---- REPORTE CERTIFICACIONES ----");
        for (Certificacion c : certificaciones) {
            System.out.println(c);
        }
    }

    @Override
    public void generarReporteEstudiantes() {
        System.out.println("---- REPORTE ESTUDIANTES ----");
        for (Estudiante e : estudiantes) {
            System.out.println(e);
        }
    }
}


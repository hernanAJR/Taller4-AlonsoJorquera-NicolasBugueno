package logica;
//Alonso Hernan Jorquera Rodriguez 20.948.058-1 ITI
//Nicolas Ignacio Bugueno Rementeria 20.007.300-2 ICCI
import java.util.Scanner;

import presentacionGUI.GUI;

public class App {
    public static void main(String[] args) {
        Sistema sistema = Sistema.getInstancia();

        // CARGA DE DATOS
        sistema.cargarEstudiantes("estudiantes.txt");
        sistema.cargarCoordinadores("coordinadores.txt");
        sistema.cargarAdministradores("administradores.txt");
        sistema.cargarCursos("cursos.txt");
        sistema.cargarCertificaciones("certificaciones.txt");
        sistema.cargarRegistros("registros.txt");
        sistema.cargarNotas("notas.txt");

        //TESTING
        Scanner teclado = new Scanner(System.in);
        int opcion;
        new GUI(sistema).setVisible(true);

        do {
            System.out.println("\n---- SISTEMA ACADEMICORE----");
            System.out.println("1. Menú Administrador");
            System.out.println("2. Menú Coordinador");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opción: ");

            opcion = teclado.nextInt();
            teclado.nextLine();

            switch (opcion) {
                case 1:
                    sistema.menuAdministrador();
                    break;
                case 2:
                    sistema.menuCoordinador();
                    break;
                case 0:
                    System.out.println("Saliendo del sistema...");
                    break;
                default:
                    System.out.println("Opción inválida.");
            }
        } while (opcion != 0);

        teclado.close();
    }
}


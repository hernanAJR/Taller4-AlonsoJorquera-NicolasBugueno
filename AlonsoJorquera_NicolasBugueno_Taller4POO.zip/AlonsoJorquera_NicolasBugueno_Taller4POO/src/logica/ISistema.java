package logica;
//Alonso Hernan Jorquera Rodriguez 20.948.058-1 ITI
//Nicolas Ignacio Bugueno Rementeria 20.007.300-2 ICCI
import dominio.*;

import java.util.List;

public interface ISistema {
    // Gestión de usuarios
    void agregarUsuario(Usuario usuario);
    Usuario buscarUsuario(String nombreUsuario);
    void eliminarUsuario(String nombreUsuario);

    // Gestión de estudiantes
    void inscribirEstudianteEnCertificacion(String rutEstudiante, String idCertificacion);
    List<Certificacion> obtenerCertificacionesEstudiante(String rutEstudiante);

    // Gestión de certificaciones
    void agregarCertificacion(Certificacion certificacion);
    Certificacion buscarCertificacion(String idCertificacion);

    // Gestión de cursos
    void agregarCurso(Curso curso);
    Curso buscarCurso(String nrc);

    // Reportes y métricas
    void generarReporteCertificaciones();
    void generarReporteEstudiantes();
}

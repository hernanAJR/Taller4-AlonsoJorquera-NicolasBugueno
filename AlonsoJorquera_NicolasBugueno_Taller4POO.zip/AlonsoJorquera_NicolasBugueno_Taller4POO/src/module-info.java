/**
 * 
 */
/**
 * 
 */
module AlonsoJorquera_NicolasBugueno_Taller4POO {
	requires java.desktop;
}
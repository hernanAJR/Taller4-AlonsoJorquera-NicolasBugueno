package dominio;
//Alonso Hernan Jorquera Rodriguez 20.948.058-1 ITI
//Nicolas Ignacio Bugueno Rementeria 20.007.300-2 ICCI
import java.util.ArrayList;
import java.util.List;

public class Estudiante extends Usuario {
    private String rut;
    private String nombre;
    private String carrera;
    private int semestre;
    private String correo;
    private ArrayList<Nota> notasEstudiante;
    private int creditosAprobados;
    
    private List<Curso> cursosAprobados;
    private List<Curso> cursosReprobados;
    private List<Curso> cursosPendientes;
    
    public Estudiante(String nombreUsuario, String contrasena, String rut, String nombre, 
                      String carrera, int semestre, String correo) {
        super(nombreUsuario, contrasena, "Estudiante", null);
        this.rut = rut;
        this.nombre = nombre;
        this.carrera = carrera;
        this.semestre = semestre;
        this.correo = correo;
        this.notasEstudiante = new ArrayList<>();
        this.creditosAprobados = calcularCreditosAprobados();
        
        this.cursosAprobados = new ArrayList<>();
        this.cursosReprobados = new ArrayList<>();
        this.cursosPendientes = new ArrayList<>();
        
    }
    /**
     * Calcula los creditos aprobados del estudiante recursivamente.
     * 
     * @return el total de creditos aprobados.
     */
    private int calcularCreditosAprobados() {
    	int contador=0;
    	for(Nota nota : notasEstudiante) {
    		if(nota.getEstado().toLowerCase().equals("aprobado")) {
    			contador+=nota.getCurso().getCreditos();
    		}
    	}
    	return contador;
    }
    /**
     * Calcula el promedio de las notas del estudiante recursivamente.
     * 
     * @return el promedio de notas del estudiante
     */
    public double calcularPromedio() {
    	double total=0;
    	double promedio = 0;
    	for(Nota nota : notasEstudiante) {
    		total+=nota.getCalificacion();
    	}
    	promedio = total/notasEstudiante.size();
    	return promedio;
    }
    
    public ArrayList<Nota> getNotasEstudiante() {
		return notasEstudiante;
	}

	public void setNotasEstudiante(ArrayList<Nota> notasEstudiante) {
		this.notasEstudiante = notasEstudiante;
	}

	public int getCreditosAprobados() {
		return creditosAprobados;
	}

	public void setCreditosAprobados(int creditosAprobados) {
		this.creditosAprobados = creditosAprobados;
	}

	public String getRut() {
		return rut;
	}


	public void setRut(String rut) {
		this.rut = rut;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public String getCarrera() {
		return carrera;
	}


	public void setCarrera(String carrera) {
		this.carrera = carrera;
	}


	public int getSemestre() {
		return semestre;
	}


	public void setSemestre(int semestre) {
		this.semestre = semestre;
	}


	public String getCorreo() {
		return correo;
	}


	public void setCorreo(String correo) {
		this.correo = correo;
	}
	/**
	 * Carga en sus respectivas listas del alumno los cursos aprobados, pendientes y reprobados.
	 * 
	 */
	public void cargarCursosPorCategoria() {
		for(Nota n : notasEstudiante) {
			switch(n.getEstado().toLowerCase()) {
			case "aprobado":
				cursosAprobados.add(n.getCurso());
			case "pendiente":
				cursosPendientes.add(n.getCurso());
			case "reprobado":
				cursosReprobados.add(n.getCurso());
			}
		}
	}

	@Override
    public String toString() {
        return "Estudiante: " + nombre + " (" + rut + "), Carrera: " + carrera;
    }


	public void agregarNota(Nota nota) {
		notasEstudiante.add(nota);
		
	}
	
}

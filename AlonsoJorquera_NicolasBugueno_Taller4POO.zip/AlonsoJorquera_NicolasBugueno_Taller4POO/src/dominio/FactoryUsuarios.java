package dominio;
//Alonso Hernan Jorquera Rodriguez 20.948.058-1 ITI
//Nicolas Ignacio Bugueno Rementeria 20.007.300-2 ICCI
public class FactoryUsuarios {

    public static Usuario crearUsuario(String rol, String nombreUsuario, String contrasena, 
                                       String rut, String nombre, String carrera, 
                                       int semestre, String correo, String areaCoordinacion) {
        switch (rol.toLowerCase()) {
            case "administrador":
                return new Administrador(nombreUsuario, contrasena);

            case "coordinador":
                return new Coordinador(nombreUsuario, contrasena, areaCoordinacion);

            case "estudiante":
                return new Estudiante(nombreUsuario, contrasena, rut, nombre, carrera, semestre, correo);

            default:
                throw new IllegalArgumentException("Rol desconocido: " + rol);
        }
    }
}

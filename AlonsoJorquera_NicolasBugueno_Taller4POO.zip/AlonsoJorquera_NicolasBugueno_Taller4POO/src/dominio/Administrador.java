package dominio;
//Alonso Hernan Jorquera Rodriguez 20.948.058-1 ITI
//Nicolas Ignacio Bugueno Rementeria 20.007.300-2 ICCI
public class Administrador extends Usuario {
    public Administrador(String nombreUsuario, String contrasena) {
        super(nombreUsuario, contrasena, "Administrador", null);
    }
} 
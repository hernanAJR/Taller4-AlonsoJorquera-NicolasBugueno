package dominio;
//Alonso Hernan Jorquera Rodriguez 20.948.058-1 ITI
//Nicolas Ignacio Bugueno Rementeria 20.007.300-2 ICCI
public class Nota {
    private String rutEstudiante;
    private String codigoCurso;
    private double calificacion;
    private String estado;
    private String semestre;
    private Curso curso;
    


	public Nota(String rutEstudiante, String codigoCurso, double calificacion, String estado, String semestre) {
        this.rutEstudiante = rutEstudiante;
        this.codigoCurso = codigoCurso;
        this.calificacion = calificacion;
        this.estado = estado;
        this.semestre = semestre;
    }
    
	public Curso getCurso() {
		return curso;
	}
	
	
	public void setCurso(Curso curso) {
		this.curso = curso;
	}
    
    public String getRutEstudiante() {
		return rutEstudiante;
	}


	public void setRutEstudiante(String rutEstudiante) {
		this.rutEstudiante = rutEstudiante;
	}


	public String getCodigoCurso() {
		return codigoCurso;
	}


	public void setCodigoCurso(String codigoCurso) {
		this.codigoCurso = codigoCurso;
	}


	public double getCalificacion() {
		return calificacion;
	}


	public void setCalificacion(double calificacion) {
		this.calificacion = calificacion;
	}


	public String getEstado() {
		return estado;
	}


	public void setEstado(String estado) {
		this.estado = estado;
	}


	public String getSemestre() {
		return semestre;
	}


	public void setSemestre(String semestre) {
		this.semestre = semestre;
	}


	@Override
    public String toString() {
        return "Nota: Estudiante " + rutEstudiante + ", Curso " + codigoCurso + 
               ", Calificación: " + calificacion + ", Estado: " + estado;
    }
}

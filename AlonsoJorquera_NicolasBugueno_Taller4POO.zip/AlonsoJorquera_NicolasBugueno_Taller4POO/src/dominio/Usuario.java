package dominio;
//Alonso Hernan Jorquera Rodriguez 20.948.058-1 ITI
//Nicolas Ignacio Bugueno Rementeria 20.007.300-2 ICCI
public abstract class Usuario {
    protected String nombreUsuario;
    protected String contrasena;
    protected String rol;
    protected String areaCoordinacion;

    public Usuario(String nombreUsuario, String contrasena, String rol, String areaCoordinacion) {
        this.nombreUsuario = nombreUsuario;
        this.contrasena = contrasena;
        this.rol = rol;
        this.areaCoordinacion = areaCoordinacion;
    }

    // GETTERS Y SETTERS
    public String getNombreUsuario() { return nombreUsuario; }
    public void setNombreUsuario(String nombreUsuario) { this.nombreUsuario = nombreUsuario; }

    public String getContrasena() { return contrasena; }
    public void setContrasena(String contrasena) { this.contrasena = contrasena; }

    public String getRol() { return rol; }
    public void setRol(String rol) { this.rol = rol; }

    public String getAreaCoordinacion() { return areaCoordinacion; }
    public void setAreaCoordinacion(String areaCoordinacion) { this.areaCoordinacion = areaCoordinacion; }

    @Override
    public String toString() {
        return "Usuario: " + nombreUsuario + ", Rol: " + rol;
    }
}

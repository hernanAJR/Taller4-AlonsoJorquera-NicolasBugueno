package dominio;

public class Ciberseguridad extends Certificacion {

	public Ciberseguridad(String id, String nombre, String descripcion, int requisitosCreditos, int validezAnios) {
		super(id, nombre, descripcion, requisitosCreditos, validezAnios);
		
	}
    public void accept(VisitorCertificaciones visitor) {
        visitor.visit(this);
    }
}

package dominio;

public interface VisitorCertificaciones {

	void visit(DesarrolloSoftware desarrolloSoftware);
	void visit(Ciberseguridad cb);
	void visit(SistemasInteligentes si);
}
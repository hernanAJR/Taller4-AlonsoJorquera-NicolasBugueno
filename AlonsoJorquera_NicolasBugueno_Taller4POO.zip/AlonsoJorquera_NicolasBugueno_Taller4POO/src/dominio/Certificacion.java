package dominio;
//Alonso Hernan Jorquera Rodriguez 20.948.058-1 ITI
//Nicolas Ignacio Bugueno Rementeria 20.007.300-2 ICCI
import java.util.List;

public class Certificacion {
    private String id;
    private String nombre;
    private String descripcion;
    private int requisitosCreditos;
    private int validezAnios;
    private List<Curso> cursos;

    public Certificacion(String id, String nombre, String descripcion, int requisitosCreditos, int validezAnios) {
        this.id = id;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.requisitosCreditos = requisitosCreditos;
        this.validezAnios = validezAnios;
    }
    

    public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public String getDescripcion() {
		return descripcion;
	}


	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}


	public int getRequisitosCreditos() {
		return requisitosCreditos;
	}


	public void setRequisitosCreditos(int requisitosCreditos) {
		this.requisitosCreditos = requisitosCreditos;
	}


	public int getValidezAnios() {
		return validezAnios;
	}


	public void setValidezAnios(int validezAnios) {
		this.validezAnios = validezAnios;
	}


	public List<Curso> getCursos() {
		return cursos;
	}


	public void setCursos(List<Curso> cursos) {
		this.cursos = cursos;
	}


	@Override
    public String toString() {
        return "Certificación: " + nombre + " - Requisitos: " + requisitosCreditos + " créditos";
    }
}

package dominio;

public class DesarrolloSoftware extends Certificacion {

	public DesarrolloSoftware(String id, String nombre, String descripcion, int requisitosCreditos, int validezAnios) {
		super(id, nombre, descripcion, requisitosCreditos, validezAnios);
	}
    public void accept(VisitorCertificaciones visitor) {
        visitor.visit(this);
    }
}

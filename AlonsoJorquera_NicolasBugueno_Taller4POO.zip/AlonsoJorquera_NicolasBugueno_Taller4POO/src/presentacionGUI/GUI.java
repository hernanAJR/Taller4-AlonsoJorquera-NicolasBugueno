package presentacionGUI;
//Alonso Hernan Jorquera Rodriguez 20.948.058-1 ITI
//Nicolas Ignacio Bugueno Rementeria 20.007.300-2 ICCI
import dominio.*;
import logica.*;
import javax.swing.*;
import java.awt.event.*; 

public class GUI extends JFrame {
    private Sistema sistema;

    public GUI(Sistema sistema) {
        this.sistema = sistema;

        setTitle("AcademiCore");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Botones principales
        JButton btnAdmin = new JButton("Menú Administrador");
        JButton btnCoord = new JButton("Menú Coordinador");

        btnAdmin.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mostrarMenuAdministrador();
            }
        });

        btnCoord.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mostrarMenuCoordinador();
            }
        });

        // Panel principal
        JPanel panel = new JPanel();
        panel.add(btnAdmin);
        panel.add(btnCoord);

        add(panel);
    }

    // Métodos para mostrar menús
    private void mostrarMenuAdministrador() {
        JFrame ventanaAdmin = new JFrame("Menú Administrador");
        ventanaAdmin.setSize(400, 300);
        ventanaAdmin.setLocationRelativeTo(null);

        JButton btnCrear = new JButton("Crear Usuario");
        JButton btnModificar = new JButton("Modificar Usuario");
        JButton btnEliminar = new JButton("Eliminar Usuario");
        JButton btnReset = new JButton("Restablecer Contraseña");

        btnCrear.addActionListener(e ->{ 
        
        	});
        btnModificar.addActionListener(e -> {
        	
        });
        btnEliminar.addActionListener(e -> {
        	
        });
        btnReset.addActionListener(e -> {
        	
        });

        JPanel panel = new JPanel();
        panel.add(btnCrear);
        panel.add(btnModificar);
        panel.add(btnEliminar);
        panel.add(btnReset);

        ventanaAdmin.add(panel);
        ventanaAdmin.setVisible(true);
    }

    private void mostrarMenuCoordinador() {
        JFrame ventanaCoord = new JFrame("Menú Coordinador");
        ventanaCoord.setSize(400, 300);
        ventanaCoord.setLocationRelativeTo(null);

        JButton btnCertificaciones = new JButton("Gestión de Certificaciones");
        JButton btnMetricas = new JButton("Panel de Métricas");
        JButton btnEstudiantes = new JButton("Gestión de Estudiantes");

        btnCertificaciones.addActionListener(e -> {
        	
        });
        btnMetricas.addActionListener(e -> {
        	
        });
        btnEstudiantes.addActionListener(e ->{
        	
        });

        JPanel panel = new JPanel();
        panel.add(btnCertificaciones);
        panel.add(btnMetricas);
        panel.add(btnEstudiantes);

        ventanaCoord.add(panel);
        ventanaCoord.setVisible(true);
    }
}
